#ifndef INSERTH
    #define INSERTH

    #include "op_bin.h"
    #include "util.h"
    #include "reg.h"
    #include "indice.h"
    #include "create.h"

    void insert_into(char * arquivoDados, char * arquivoIndice, int numInsert);


#endif